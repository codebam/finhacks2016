# __variables__ with double-quoted values will be available in setup.py:
__version__ = "0.30.0.a0"
